// 10x20 フィールド & 互換API（getFieldSize エイリアス）
// ★ getSize()/getFieldSize() は常に同じオブジェクト参照を返す（無限リサイズ防止）

const WIDTH = 10;
const HEIGHT = 20;

// 互換用に定数も公開（draw.js から直接 import される可能性に備える）
export const FIELD_WIDTH = WIDTH;
export const FIELD_HEIGHT = HEIGHT;

// 同一参照を返すためのシングルトン
const SIZE = Object.freeze({ WIDTH, HEIGHT });

export function createEmptyField() {
  return Array.from({ length: HEIGHT }, () => Array(WIDTH).fill(0));
}

export function initField() {
  return createEmptyField();
}

// ★ここがポイント：毎回新しいオブジェクトを作らず、同じ参照を返す
export function getSize() {
  return SIZE;
}

// ★互換エクスポート：古い draw.js が期待する名前
export function getFieldSize() {
  return SIZE;
}

// 任意補助
export function getWidth() { return WIDTH; }
export function getHeight() { return HEIGHT; }

export function checkCollision(field, mino) {
  const s = mino.shape;
  for (let y = 0; y < s.length; y++) {
    for (let x = 0; x < s[0].length; x++) {
      if (!s[y][x]) continue;
      const fx = mino.x + x;
      const fy = mino.y + y;
      if (fx < 0 || fx >= WIDTH || fy >= HEIGHT) return true;
      if (fy >= 0 && field[fy][fx]) return true;
    }
  }
  return false;
}

export function placeMino(field, mino) {
  const s = mino.shape;
  for (let y = 0; y < s.length; y++) {
    for (let x = 0; x < s[0].length; x++) {
      if (!s[y][x]) continue;
      const fx = mino.x + x;
      const fy = mino.y + y;
      if (fy >= 0 && fy < field.length && fx >= 0 && fx < field[0].length) {
        field[fy][fx] = 1; // 色IDを載せるならここを拡張
      }
    }
  }
}

export function clearLines(field) {
  let cleared = 0;
  for (let y = field.length - 1; y >= 0; y--) {
    if (field[y].every(v => v !== 0)) {
      field.splice(y, 1);
      field.unshift(new Array(WIDTH).fill(0));
      cleared++;
      y++; // splice後は同じインデックスを再チェック
    }
  }
  return cleared;
}

export function isPerfectClear(field) {
  for (let y = 0; y < field.length; y++) {
    for (let x = 0; x < field[0].length; x++) {
      if (field[y][x] !== 0) return false;
    }
  }
  return true;
}