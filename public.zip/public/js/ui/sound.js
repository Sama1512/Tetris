export class Sound {
    constructor() {
        this.ctx = null;
        this.buffers = new Map();
        this.muted = false;
        this.volume = 0.6;
        this.assets = {
        move:"/assets/sfx/move.mp3", rotate:"/assets/sfx/rotate.mp3",
        hard:"/assets/sfx/harddrop.mp3", hold:"/assets/sfx/hold.mp3",
        clear1:"/assets/sfx/clear1.mp3", tetris:"/assets/sfx/tetris.mp3",
        tspin:"/assets/sfx/tspin.mp3", pc:"/assets/sfx/allclear.mp3",
        level:"/assets/sfx/levelup.mp3",
        };
        try {
        const s = JSON.parse(localStorage.getItem("settings") || "{}");
        if (typeof s.mute === "boolean") this.muted = s.mute;
        if (Number.isFinite(s["sfx-volume"])) this.volume = Math.max(0,Math.min(1,s["sfx-volume"]));
        } catch {}
    }
    attachUnlock() {
        const unlock = () => {
        if (!this.ctx) {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (AC) this.ctx = new AC();
        }
        window.removeEventListener("pointerdown", unlock);
        window.removeEventListener("keydown", unlock);
        };
        window.addEventListener("pointerdown", unlock);
        window.addEventListener("keydown", unlock);
    }
    async _ensureCtx() {
        if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        this.ctx = new AC();
        }
        if (this.ctx.state === "suspended") await this.ctx.resume().catch(()=>{});
        return this.ctx;
    }
    async _load(name) {
        if (this.buffers.has(name)) return this.buffers.get(name);
        const url = this.assets[name]; if (!url) return null;
        try {
        const ctx = await this._ensureCtx(); if (!ctx) return null;
        const res = await fetch(url, { cache:"force-cache" }); if (!res.ok) throw 0;
        const buf = await ctx.decodeAudioData((await res.arrayBuffer()).slice(0));
        this.buffers.set(name, buf); return buf;
        } catch { this.buffers.set(name, null); return null; }
    }
    async play(name,{rate=1,volume=this.volume}={}) {
        if (this.muted) return;
        const ctx = await this._ensureCtx(); if (!ctx) return;
        const buf = await this._load(name);
        if (buf) {
        const src = ctx.createBufferSource(); src.buffer = buf; src.playbackRate.value = rate;
        const gain = ctx.createGain(); gain.gain.value = volume;
        src.connect(gain).connect(ctx.destination); src.start(); return;
        }
        // fallback beep
        const osc = ctx.createOscillator(), gain = ctx.createGain(), now = ctx.currentTime;
        osc.type="triangle"; osc.frequency.setValueAtTime(this._freq(name), now);
        gain.gain.setValueAtTime(volume*0.3, now); gain.gain.exponentialRampToValueAtTime(0.0001, now+0.08);
        osc.connect(gain).connect(ctx.destination); osc.start(now); osc.stop(now+0.09);
    }
    _freq(name){ return ({move:440,rotate:660,hard:880,hold:520,clear1:600,tetris:420,tspin:700,pc:940,level:500})[name]||500; }
    setMute(m){ this.muted=!!m; } setVolume(v){ this.volume=Math.max(0,Math.min(1,v)); }
}