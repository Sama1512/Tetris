export const THEMES = { neo: "neo", dark: "dark" };

export function applyTheme(name = "neo") {
    const t = THEMES[name] ? name : "neo";
    document.body.setAttribute("data-theme", t);
    try {
        const s = JSON.parse(localStorage.getItem("settings") || "{}");
        s.theme = t;
        localStorage.setItem("settings", JSON.stringify(s));
    } catch {}
}

export function loadThemeFromSettings() {
    try {
        const s = JSON.parse(localStorage.getItem("settings") || "{}");
        applyTheme(s.theme || "neo");
    } catch { applyTheme("neo"); }
}