import { initDraw, drawField, drawMino, drawNext, drawHold, setDrawState, drawGhost } from "../core/draw.js";
import { initField, checkCollision, placeMino, clearLines, isPerfectClear } from "../core/field.js";
import { getNextBag, rotateMino, cloneMino } from "../core/mino.js";
import { initInput } from "../core/input.js";
import { ScoreManager } from "../core/score.js";
import { classifyTSpinStrict } from "../core/tspin.js";

export class SingleGameBase {
  constructor(canvasId, nextCount = 5, onStateUpdate = null) {
    this.canvas = document.getElementById(canvasId);
    this.currentMino = null;
    this.holdMino = null;
    this.canHold = true;
    this.nextQueue = [];
    this.field = initField();
    this.nextCount = nextCount;
    this.onStateUpdate = onStateUpdate;

    this.scoreManager = new ScoreManager();
    this.isGameOver = false;

    // 設定（_loadSettingsで上書き）
    this.enableHold = true;
    this.enableHardDrop = true;
    this.reverseRotation = false;
    this.showGhost = true;

    // T-Spin用フラグ
    this.lastSpin = { rotated: false };

    this.init();
  }

  // --- 設定読込：settings と単発キーをマージ（単発キーが優先） ---
  _loadSettings() {
    // util
    const toBool = (v, def) => {
      if (typeof v === "boolean") return v;
      if (typeof v === "number") return v !== 0;
      if (typeof v === "string") {
        const s = v.toLowerCase();
        if (["1","true","on","yes"].includes(s)) return true;
        if (["0","false","off","no"].includes(s)) return false;
      }
      return def;
    };
    const readBool = (k) => {
      const v = localStorage.getItem(k);
      if (v == null) return undefined;
      return toBool(v, undefined);
    };
    const readInt = (k) => {
      const v = localStorage.getItem(k);
      if (v == null) return undefined;
      const n = Number(v);
      return Number.isFinite(n) ? (n|0) : undefined;
    };

    // 1) settings系JSON（あれば）
    const pickSettings = () => {
      const keys = ["settings","tetrisSettings","gameSettings","TetrisSettings","TETRIS_SETTINGS"];
      for (const k of keys) {
        const raw = localStorage.getItem(k);
        if (!raw) continue;
        try { return JSON.parse(raw); } catch {}
      }
      return {};
    };
    const base = pickSettings(); // 既存settings（無ければ {}）

    // 2) 単発キー（最新の実値）を収集
    const flat = {
      "show-ghost":       readBool("show-ghost"),
      "enable-hold":      readBool("enable-hold"),
      "enable-harddrop":  readBool("enable-harddrop"),
      "reverse-rotation": readBool("reverse-rotation"),
      "show-time":        readBool("show-time"),
      "next-count":       readInt("next-count"),
      "das":              readInt("das"),
      "arr":              readInt("arr"),
      "lock-delay":       readInt("lock-delay"),
    };
    Object.keys(flat).forEach(k => flat[k] === undefined && delete flat[k]);

    // 3) マージ（単発キーが優先）＋ 正規化
    const s = { ...base, ...flat };

    // 4) this に適用（ハイフン/キャメル両対応）
    const gv = (h, c, d) => (s[h] ?? s[c] ?? d);
    this.showGhost       = toBool(gv("show-ghost","showGhost", this.showGhost), this.showGhost);
    this.enableHold      = toBool(gv("enable-hold","enableHold", this.enableHold), this.enableHold);
    this.enableHardDrop  = toBool(gv("enable-harddrop","enableHardDrop", this.enableHardDrop), this.enableHardDrop);
    this.reverseRotation = toBool(gv("reverse-rotation","reverseRotation", this.reverseRotation), this.reverseRotation);

    const nc = gv("next-count","nextCount", this.nextCount);
    if (Number.isFinite(nc) && nc > 0) this.nextCount = nc|0;

    // 5) 正規化した settings を保存（将来はこれだけ読めばOK）
    try {
      const normalized = {
        "show-ghost": this.showGhost,
        "enable-hold": this.enableHold,
        "enable-harddrop": this.enableHardDrop,
        "reverse-rotation": this.reverseRotation,
        "next-count": this.nextCount,
        // 使う予定のパラメータも持ち越し（存在していれば）
        ...(Number.isFinite(s.das)        ? { das: s.das|0 } : {}),
        ...(Number.isFinite(s.arr)        ? { arr: s.arr|0 } : {}),
        ...(Number.isFinite(s["lock-delay"]) ? { "lock-delay": s["lock-delay"]|0 } : {}),
        ...(typeof s["show-time"] === "boolean" ? { "show-time": s["show-time"] } : {}),
      };
      localStorage.setItem("settings", JSON.stringify(normalized));
    } catch {}

    // HOLDパネルの表示/非表示（ID/クラス候補）
    const holdWrapper =
      document.getElementById("hold-wrapper") ||
      document.getElementById("hold-area") ||
      document.querySelector(".hold-wrapper");
    if (holdWrapper) holdWrapper.style.display = this.enableHold ? "" : "none";

    // デバッグ（実際に適用された値）
    console.debug("[settings applied]", {
      showGhost: this.showGhost,
      enableHold: this.enableHold,
      enableHardDrop: this.enableHardDrop,
      reverseRotation: this.reverseRotation,
      nextCount: this.nextCount,
    });
  }

  init() {
    initDraw(this.canvas);
    // 先に公開→コンソールから __game.* で実値を確認できる
    window.__game = this;
    this._loadSettings();
    initInput(this.handleKey.bind(this));
  }

  reset() {
    this.field = initField();
    this.nextQueue = [...getNextBag()];
    while (this.nextQueue.length < this.nextCount) this.nextQueue.push(...getNextBag());
    this.holdMino = null;
    this.canHold = true;
    this.scoreManager.reset?.();
    this.isGameOver = false;
    this.updateState();
  }

  start() {
    // 設定画面→戻ってきた直後でも確実に反映
    this._loadSettings();
    this.reset();
    this.spawnMino();
  }

  spawnMino() {
    this.currentMino = this.nextQueue.shift();
    if (this.nextQueue.length <= 7) this.nextQueue.push(...getNextBag());
    this.currentMino.x = 4;
    this.currentMino.y = 0;
    this.canHold = true;

    if (checkCollision(this.field, this.currentMino)) {
      this.onGameOver?.();
    } else {
      this.render();
    }
    this.updateState();
  }

  hold() {
    if (!this.enableHold || !this.canHold) return;
    const temp = this.holdMino;
    this.holdMino = cloneMino(this.currentMino);
    if (temp) this.currentMino = cloneMino(temp);
    else {
      this.currentMino = this.nextQueue.shift();
      this.nextQueue.push(...getNextBag());
    }
    this.currentMino.x = 4;
    this.currentMino.y = 0;
    this.canHold = false;
    this.lastSpin = { rotated: false };
    this.render();
  }

  rotate(dir) {
    // 逆回転設定の反映
    const realDir =
      (dir === "left")
        ? (this.reverseRotation ? "right" : "left")
        : (this.reverseRotation ? "left"  : "right");

    const rotated = rotateMino(this.currentMino, realDir);
    if (!checkCollision(this.field, rotated)) {
      this.currentMino = rotated;
      this.lastSpin = { rotated: true };
      this.render();
    }
  }

  hardDrop() {
    if (!this.enableHardDrop) return;
    while (!checkCollision(this.field, { ...this.currentMino, y: this.currentMino.y + 1 })) {
      this.currentMino.y++;
    }
    this.lockAndScore();
  }

  moveMino(dx, dy) {
    const next = { ...this.currentMino, x: this.currentMino.x + dx, y: this.currentMino.y + dy };
    if (!checkCollision(this.field, next)) {
      this.currentMino = next;
      if (dy === 1) this.lastSpin = { rotated: false }; // 落下でフラグOFF
      this.render();
    } else if (dy === 1) {
      this.lockAndScore();
    }
    this.updateState();
  }

  // T-Spin / PC の判定を集約
  lockAndScore() {
    placeMino(this.field, this.currentMino);

    const fieldBeforeClear = this.field.map(r => r.slice());
    const cleared = clearLines(this.field);

    const type = (typeof classifyTSpinStrict === "function")
      ? classifyTSpinStrict(this.currentMino, fieldBeforeClear, this.lastSpin, cleared)
      : "normal";

    this.lastSpin = { rotated: false };

    // 行消しがあった時だけPC判定
    const pc = (cleared > 0) && isPerfectClear(this.field);

    // 互換 onClear（第2引数は任意）
    this.onClear?.(cleared, { type, perfectClear: pc });

    this.spawnMino();
  }

  render() {
    drawField(this.field);
    if (this.showGhost && this.currentMino) drawGhost(this.field, this.currentMino);
    drawMino(this.currentMino);
    drawNext(this.nextQueue, this.nextCount);
    drawHold(this.holdMino);
    setDrawState({
      field: this.field,
      mino: this.currentMino,
      queue: this.nextQueue,
      count: this.nextCount,
      hold: this.holdMino,
    });
  }

  updateState() {
    this.onStateUpdate?.({
      field: this.field,
      mino: this.currentMino,
      queue: this.nextQueue,
      count: this.nextCount,
      hold: this.holdMino,
    });
  }

  handleKey(action) {
    if (this.isGameOver) return;
    switch (action) {
      case "moveLeft": this.moveMino(-1, 0); break;
      case "moveRight": this.moveMino(1, 0); break;
      case "softDrop": this.moveMino(0, 1); break;
      case "rotateLeft": this.rotate("left"); break;
      case "rotateRight": this.rotate("right"); break;
      case "hold": this.hold(); break;
      case "hardDrop": this.hardDrop(); break;
    }
  }
}