export function recordReplayFrame(state) {
    // 入力、フィールド状態などをログに保存
}